'use client';

import { useState } from 'react';
import type { Student } from '@/lib/types';
import type { AppUser } from '@/hooks/use-user';
import { updateStudentAcademicIntake } from '@/lib/actions';
import { useToast } from '@/hooks/use-toast';

// UI Components
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Loader2, FilePenLine, CheckCircle, XCircle, PlusCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface AcademicIntakeCardProps {
  student: Student;
  currentUser: AppUser;
}

const semesters = [
  'FALL (8/9)',
  'SPRING (1/2)',
  'MARCH (3)',
  'SUMMER (6/7)'
];

const years = [2026, 2027, 2028, 2029, 2030];

export function AcademicIntakeCard({ student, currentUser }: AcademicIntakeCardProps) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [tempSemester, setTempSemester] = useState<string>(student.academicIntakeSemester || '');
  const [tempYear, setTempYear] = useState<string>(student.academicIntakeYear?.toString() || '');

  const isAdminOrDept = currentUser?.role === 'admin' || currentUser?.role === 'department';
  const isAssignedEmployee = currentUser?.civilId === student.employeeId;
  const canEdit = isAdminOrDept || isAssignedEmployee;

  const handleSave = async () => {
    if (!tempSemester || !tempYear) {
      toast({ 
        variant: 'destructive', 
        title: 'Selection Required', 
        description: 'Please select both a semester and a year.' 
      });
      return;
    }

    setIsLoading(true);
    const result = await updateStudentAcademicIntake(
      student.id, 
      tempSemester, 
      parseInt(tempYear), 
      currentUser.id
    );

    if (result.success) {
      toast({ title: 'Intake Saved', description: result.message });
      setIsEditing(false);
    } else {
      toast({ variant: 'destructive', title: 'Update Failed', description: result.message });
    }
    setIsLoading(false);
  };

  const handleCancel = () => {
    setTempSemester(student.academicIntakeSemester || '');
    setTempYear(student.academicIntakeYear?.toString() || '');
    setIsEditing(false);
  };

  return (
    <Card className="border-primary/20 bg-primary/5">
      <CardHeader className="flex flex-row items-center justify-between py-4">
        <div className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-primary" />
          <CardTitle className="text-lg">Academic term</CardTitle>
        </div>
        {!isEditing && student.academicIntakeSemester && canEdit && (
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setIsEditing(true)}>
            <FilePenLine className="h-4 w-4" />
            <span className="sr-only">Edit term</span>
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {!isEditing ? (
          <div className="flex items-center gap-3">
            {student.academicIntakeSemester ? (
              <div className="flex items-center gap-2 bg-background border px-4 py-2 rounded-full shadow-sm w-full justify-between">
                <div className="flex items-center gap-2">
                    <span className="font-bold text-primary">{student.academicIntakeSemester}</span>
                    <span className="font-mono text-muted-foreground">{student.academicIntakeYear}</span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center w-full py-4 space-y-3">
                <p className="text-sm text-muted-foreground italic">No academic intake set</p>
                {canEdit && (
                  <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Add Intake
                  </Button>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground uppercase">Semester</label>
                <Select value={tempSemester} onValueChange={setTempSemester}>
                    <SelectTrigger className="bg-background">
                    <SelectValue placeholder="Select Semester" />
                    </SelectTrigger>
                    <SelectContent>
                    {semesters.map(s => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                    </SelectContent>
                </Select>
                </div>
                <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground uppercase">Year</label>
                <Select value={tempYear} onValueChange={setTempYear}>
                    <SelectTrigger className="bg-background">
                    <SelectValue placeholder="Select Year" />
                    </SelectTrigger>
                    <SelectContent>
                    {years.map(y => (
                        <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                    ))}
                    </SelectContent>
                </Select>
                </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" size="sm" onClick={handleCancel} disabled={isLoading}>
                    <XCircle className="h-4 w-4 mr-2" />
                    Cancel
                </Button>
                <Button size="sm" onClick={handleSave} disabled={isLoading}>
                    {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <CheckCircle className="h-4 w-4 mr-2" />}
                    Save
                </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
